def run_self_play(): pass
