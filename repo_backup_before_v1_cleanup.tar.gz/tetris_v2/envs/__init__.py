"""Environments for TetrisV2."""
from .registration import register_envs
