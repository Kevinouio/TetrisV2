"""Exploration and representation modules for augmenting base agents."""
