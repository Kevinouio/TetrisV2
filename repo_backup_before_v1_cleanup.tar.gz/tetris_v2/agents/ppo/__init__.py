"""Compatibility shim for the relocated PPO package."""

from tetris_v2.agents.single_agent.ppo import *  # noqa: F401,F403,E402
