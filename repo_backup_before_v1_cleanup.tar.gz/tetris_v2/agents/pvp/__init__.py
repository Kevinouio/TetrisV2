"""Self-play and competitive (PvP) training algorithms."""
