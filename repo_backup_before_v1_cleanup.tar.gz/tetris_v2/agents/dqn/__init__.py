"""Compatibility shim for the relocated DQN package."""

from tetris_v2.agents.single_agent.dqn import *  # noqa: F401,F403,E402
