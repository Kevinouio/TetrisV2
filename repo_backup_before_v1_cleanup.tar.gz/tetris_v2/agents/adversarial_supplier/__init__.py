"""Piece-supplier adversaries that learn to minimise the player's reward."""
