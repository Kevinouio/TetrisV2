"""Compatibility wrapper for legacy import path."""

from tetris_v2.agents.heuristics.random_agent import *  # noqa: F401,F403
