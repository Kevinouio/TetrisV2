"""Experiment harnesses for ablation and algorithm comparisons."""
