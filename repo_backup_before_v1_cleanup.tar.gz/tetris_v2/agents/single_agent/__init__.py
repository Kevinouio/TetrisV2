"""Single-agent (score maximisation) algorithm implementations."""

# Re-export modules so existing imports continue to work.
from . import dqn, ppo  # noqa: F401
